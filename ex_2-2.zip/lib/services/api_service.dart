import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/product_model.dart';

class ApiService {
  static const String baseUrl = "https://escuelajs.co";

  static Future<List<Product>> fetchProducts() async {
    final url = Uri.parse(baseUrl);

    try {
      final response = await http.get(url);

      if (response.statusCode != 200) {
        throw Exception("Failed to load products");
      }

      final List<dynamic> data = jsonDecode(response.body);

      return data.map((item) { 
        String cleanImageUrl = '';
        if (item['images'] != null && item['images'].isNotEmpty) {
          cleanImageUrl = item['images'][0]
              .toString()
              .replaceAll('[', '')
              .replaceAll(']', '')
              .replaceAll('"', '');
        }

        if (!cleanImageUrl.startsWith('http')) {
          cleanImageUrl = 'https://placeholder.com';
        }

        return Product(
          id: item['id'].toString(),
          name: item['title'] ?? '',
          description: item['description'] ?? '',
          price: (item['price'] ?? 0).toDouble(),
          imageUrl: cleanImageUrl,
          category: item['category'] != null ? item['category']['name'] : 'Unknown',
        );
      }).toList();
    } catch (e) {
      print("Error fetching products: $e");
      rethrow;
    }
  }
}
