import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../models/product_model.dart';

class ProductProvider with ChangeNotifier {
  List<Product> _products = [];
  bool _isLoading = false;
  String? _error;

  List<Product> get products => [..._products];
  bool get isLoading => _isLoading;
  String? get error => _error;

  Future<void> fetchProducts() async {
    try {
      _isLoading = true;
      _error = null;
      notifyListeners();

      final url = Uri.parse(
        'https://api.escuelajs.co/api/v1/products',
      );

      final response = await http.get(url);

      if (response.statusCode != 200) {
        throw Exception('Server Error: ${response.statusCode}');
      }

      final List data = jsonDecode(response.body);

      _products = data.map((e) {
        return Product.fromJson(e);
      }).toList();

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _isLoading = false;
      _error = e.toString();
      _products = [];
      notifyListeners();
    }
  }
}
