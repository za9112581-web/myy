import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/product_model.dart';

class FavoritesProvider with ChangeNotifier {
  
  List<Product> _favoriteItems = [];
  List<Product> get favoriteItems => [..._favoriteItems];

  FavoritesProvider() {
    loadFavorites();
  }

  
  bool isFavorite(Product product) {
    return _favoriteItems.any((item) => item.id == product.id);
  }

  
  Future<void> toggleFavorite(Product product) async {
    final index = _favoriteItems.indexWhere((item) => item.id == product.id);
    
    if (index >= 0) {
      _favoriteItems.removeAt(index);
      product.isFavorite = false;
    } else {
      _favoriteItems.add(product);
      product.isFavorite = true;
    }

    await _saveToDisk();
    notifyListeners();
  }

  
  Future<void> _saveToDisk() async {
    final prefs = await SharedPreferences.getInstance();
    
    final String encodedData = jsonEncode(
      _favoriteItems.map((p) => p.toJson()).toList(),
    );
    await prefs.setString('favorites_list', encodedData);
  }

  
  Future<void> loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    final String? data = prefs.getString('favorites_list');
    
    if (data != null) {
      try {
        final List<dynamic> decoded = jsonDecode(data);
        _favoriteItems = decoded.map((item) => Product.fromJson(item)).toList();
        notifyListeners();
      } catch (e) {
        print("Error loading favorites: $e");
      }
    }
  }

  
  void syncWithProducts(List<Product> allProducts) {
    for (var p in allProducts) {
      p.isFavorite = isFavorite(p);
    }
    notifyListeners();
  }
}
