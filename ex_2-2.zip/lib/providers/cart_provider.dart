import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/product_model.dart';


class CartItem {
  final Product product;
  int quantity;
  CartItem({required this.product, this.quantity = 1});

  Map<String, dynamic> toJson() => {'product': product.toJson(), 'quantity': quantity};
  factory CartItem.fromJson(Map<String, dynamic> json) => 
      CartItem(product: Product.fromJson(json['product']), quantity: json['quantity'] ?? 1);
}


class OrderItem {
  final String id;
  final List<CartItem> products;
  final double total;
  String status;

  OrderItem({required this.id, required this.products, required this.total, this.status = "قيد المراجعة"});

  Map<String, dynamic> toJson() => {
    'id': id, 'products': products.map((e) => e.toJson()).toList(),
    'total': total, 'status': status,
  };

  factory OrderItem.fromJson(Map<String, dynamic> json) => OrderItem(
    id: json['id'].toString(), total: (json['total'] ?? 0).toDouble(),
    status: json['status'] ?? "قيد المراجعة",
    products: (json['products'] as List).map((e) => CartItem.fromJson(e)).toList(),
  );
}

class CartProvider with ChangeNotifier {
  Map<String, CartItem> _items = {};
  List<OrderItem> _orders = [];

  Map<String, CartItem> get items => {..._items};
  List<OrderItem> get orders => [..._orders];
  int get itemCount => _items.values.fold(0, (sum, item) => sum + item.quantity);
  double get totalAmount => _items.values.fold(0.0, (sum, item) => sum + (item.product.price * item.quantity));

  CartProvider() {
    _loadAllData();
  }

  void addItem(Product product) {
    if (_items.containsKey(product.id)) {
      _items.update(product.id, (ex) => CartItem(product: ex.product, quantity: ex.quantity + 1));
    } else {
      _items[product.id] = CartItem(product: product);
    }
    _saveAllData();
    notifyListeners();
  }

  
  void removeSingleItem(String productId) {
    if (!_items.containsKey(productId)) return;

    if (_items[productId]!.quantity > 1) {
      _items.update(
        productId,
        (existing) => CartItem(
          product: existing.product,
          quantity: existing.quantity - 1,
        ),
      );
    } else {
      _items.remove(productId);
    }
    _saveAllData();
    notifyListeners();
  }

  void checkout() {
    if (_items.isEmpty) return;
    final order = OrderItem(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      products: _items.values.toList(),
      total: totalAmount,
    );
    _orders.insert(0, order);
    _items.clear();
    _saveAllData();
    notifyListeners();

    Timer(const Duration(seconds: 10), () {
      order.status = "المستلمة";
      _saveAllData();
      notifyListeners();
    });
  }

  
  Future<void> _saveAllData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('cart_data', jsonEncode(_items.map((k, v) => MapEntry(k, v.toJson()))));
    await prefs.setString('orders_data', jsonEncode(_orders.map((e) => e.toJson()).toList()));
  }

  
  Future<void> _loadAllData() async {
    final prefs = await SharedPreferences.getInstance();
    final cartStr = prefs.getString('cart_data');
    if (cartStr != null) {
      final decoded = jsonDecode(cartStr) as Map<String, dynamic>;
      _items = decoded.map((k, v) => MapEntry(k, CartItem.fromJson(v)));
    }
    final ordersStr = prefs.getString('orders_data');
    if (ordersStr != null) {
      final List decoded = jsonDecode(ordersStr);
      _orders = decoded.map((e) => OrderItem.fromJson(e)).toList();
    }
    notifyListeners();
  }

  void removeItem(String id) { _items.remove(id); _saveAllData(); notifyListeners(); }
  void clearCart() { _items.clear(); _saveAllData(); notifyListeners(); }
}
