class Product {
  final String id;
  final String name;
  final String description;
  final double price;
  final String imageUrl;
  final String category;
  bool isFavorite;

  Product({
    required this.id,
    required this.name,
    required this.description,
    required this.price,
    required this.imageUrl,
    required this.category,
    this.isFavorite = false,
  });

  factory Product.fromJson(Map<String, dynamic> json) {
    String image = '';
    
    if (json['images'] != null && json['images'] is List && json['images'].isNotEmpty) {
      image = json['images'][0].toString()
          .replaceAll('[', '')
          .replaceAll(']', '')
          .replaceAll('"', '');
    }

    if (!image.startsWith('http')) {
      image = 'https://placeholder.com';
    }

    return Product(
      id: json['id'].toString(),
      name: json['title'] ?? '',
      description: json['description'] ?? '',
      price: (json['price'] ?? 0).toDouble(),
      imageUrl: image,
      category: json['category'] is Map
          ? json['category']['name'] ?? 'unknown'
          : (json['category'] ?? 'unknown').toString(),
      isFavorite: false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': name,
      'description': description,
      'price': price,
      'images': [imageUrl],
      'category': {'name': category},
      'isFavorite': isFavorite,
    };
  }
}
