import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/product_model.dart';
import '../providers/cart_provider.dart';
import '../providers/favorites_provider.dart';
import '../providers/product_provider.dart';

import 'cart_screen.dart';
import 'categories_screen.dart';
import 'favorites_screen.dart';
import 'purchases_screen.dart'; 

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;
  String? _selectedCategory;

  
  Widget _buildBody(List<Product> products) {
    if (products.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_selectedIndex == 1 && _selectedCategory != null) {
      return _buildCategoryItemsContent(products);
    }

    switch (_selectedIndex) {
      case 0:
        return _buildHomeContent(products);
      case 1:
        return CategoriesScreen(
          onCategoryTap: (cat) {
            setState(() {
              _selectedCategory = cat;
            });
          },
        );
      case 2:
        return const FavoritesScreen();
      case 3:
        return const CartScreen();
      case 4:
        return const PurchasesScreen(); 
      default:
        return _buildHomeContent(products);
    }
  }

  
  Widget _buildItemCard(Product product) {
    final favProvider = context.watch<FavoritesProvider>();
    final isFav = favProvider.isFavorite(product);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Stack(
            children: [
              Container(
                decoration: BoxDecoration(
                  color: const Color(0xFFEEEEEE),
                  borderRadius: BorderRadius.circular(28),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(28),
                  child: Image.network(
                    product.imageUrl,
                    fit: BoxFit.cover,
                    width: double.infinity,
                    height: double.infinity,
                    errorBuilder: (context, error, stackTrace) =>
                        const Center(child: Icon(Icons.image_not_supported, color: Colors.grey)),
                  ),
                ),
              ),
              Positioned(
                top: 12,
                right: 12,
                child: GestureDetector(
                  onTap: () => context.read<FavoritesProvider>().toggleFavorite(product),
                  child: Icon(
                    isFav ? Icons.favorite : Icons.favorite_border,
                    color: isFav ? Colors.red : Colors.black38,
                    size: 22,
                  ),
                ),
              ),
              Positioned(
                bottom: 12,
                right: 12,
                child: GestureDetector(
                  onTap: () {
                    context.read<CartProvider>().addItem(product);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text("تمت الإضافة للسلة"), duration: Duration(seconds: 1)),
                    );
                  },
                  child: const CircleAvatar(
                    backgroundColor: Colors.black,
                    radius: 18,
                    child: Icon(Icons.add, color: Colors.white, size: 20),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 5),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                product.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.grey, fontSize: 14, fontWeight: FontWeight.w500),
              ),
              const SizedBox(height: 2),
              Text(
                '\$${product.price}',
                style: const TextStyle(color: Color(0xFF4A90E2), fontSize: 16, fontWeight: FontWeight.w900),
              ),
            ],
          ),
        ),
      ],
    );
  }

  
  Widget _buildHomeContent(List<Product> products) {
    return SafeArea(
      bottom: false,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(25, 20, 25, 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("،مرحباً بك", style: TextStyle(color: Colors.black38, fontSize: 16)),
                Text("قائمة المنتجات", style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: -0.5)),
              ],
            ),
          ),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.fromLTRB(20, 10, 20, 120),
              itemCount: products.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 0.72,
                crossAxisSpacing: 18,
                mainAxisSpacing: 18,
              ),
              itemBuilder: (ctx, i) => _buildItemCard(products[i]),
            ),
          ),
        ],
      ),
    );
  }

  
  Widget _buildCustomBottomBar() {
    return Positioned(
      bottom: 25,
      left: 20,
      right: 20,
      child: Container(
        height: 70,
        decoration: BoxDecoration(
          color: Colors.black,
          borderRadius: BorderRadius.circular(35),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 20, offset: const Offset(0, 10)),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _navIcon(Icons.home_filled, 0),
            _navIcon(Icons.grid_view_rounded, 1),
            _navIcon(Icons.favorite_rounded, 2),
            _navIcon(Icons.shopping_bag_rounded, 3),
            _navIcon(Icons.local_shipping_rounded, 4), 
          ],
        ),
      ),
    );
  }

  Widget _navIcon(IconData icon, int index) {
    bool isSelected = _selectedIndex == index;
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedIndex = index;
          _selectedCategory = null;
        });
      },
      child: Icon(
        icon,
        color: isSelected ? Colors.white : Colors.white.withOpacity(0.4),
        size: 28,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final productProvider = context.watch<ProductProvider>();
    final products = productProvider.products;

    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FB),
      extendBody: true,
      body: Stack(
        children: [
          _buildBody(products),
          _buildCustomBottomBar(),
        ],
      ),
    );
  }

  Widget _buildCategoryItemsContent(List<Product> products) {
    final selected = (_selectedCategory ?? '').toLowerCase().trim();
    final categoryItems = products.where((p) => p.category.toLowerCase().trim() == selected).toList();

    return SafeArea(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(10),
            child: Row(
              children: [
                IconButton(icon: const Icon(Icons.arrow_back_ios_new), onPressed: () => setState(() => _selectedCategory = null)),
                Text(_selectedCategory ?? '', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              ],
            ),
          ),
          Expanded(
            child: categoryItems.isEmpty
                ? const Center(child: Text("لا توجد منتجات"))
                : GridView.builder(
                    padding: const EdgeInsets.fromLTRB(20, 10, 20, 120),
                    itemCount: categoryItems.length,
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 0.72,
                      crossAxisSpacing: 18,
                      mainAxisSpacing: 18,
                    ),
                    itemBuilder: (ctx, i) => _buildItemCard(categoryItems[i]),
                  ),
          ),
        ],
      ),
    );
  }
}
