import 'package:flutter/material.dart';

class CategoriesScreen extends StatelessWidget {
  final Function(String) onCategoryTap;

  const CategoriesScreen({super.key, required this.onCategoryTap});

    
  static const List<Map<String, dynamic>> categories = [
    {
      'title': 'Clothes',
      'label': 'الملابس',
      'icon': Icons.checkroom_rounded,
      'color': Color(0xFF6366F1)
    },
    {
      'title': 'Electronics',
      'label': 'الإلكترونيات',
      'icon': Icons.electrical_services_rounded,
      'color': Color(0xFFEC4899)
    },
    {
      'title': 'Furniture',
      'label': 'الأثاث',
      'icon': Icons.chair_rounded,
      'color': Color(0xFF8B5CF6)
    },
    {
      'title': 'Shoes',
      'label': 'الأحذية',
      'icon': Icons.straighten_rounded,
      'color': Color(0xFF10B981)
    },
    {
      'title': 'Miscellaneous',
      'label': 'متنوعات',
      'icon': Icons.category_rounded,
      'color': Color(0xFFF59E0B)
    },
  ];

  String normalize(String value) => value.toLowerCase().trim();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFBFBFF),
      body: CustomScrollView(
        slivers: [
          const SliverAppBar(
            expandedHeight: 120,
            backgroundColor: Colors.transparent,
            elevation: 0,
            flexibleSpace: FlexibleSpaceBar(
              titlePadding: EdgeInsets.only(left: 25, bottom: 15),
              title: Text(
                'التصنيفات',
                style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.w900,
                  fontSize: 24,
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate(
                (ctx, i) {
                  final category = categories[i];

                  return Container(
                    margin: const EdgeInsets.only(bottom: 15),
                    height: 90,
                    child: GestureDetector(
                      onTap: () {
                        onCategoryTap(normalize(category['title']));
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(22),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.03),
                              blurRadius: 10,
                              offset: const Offset(0, 5),
                            ),
                          ],
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          child: Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: (category['color'] as Color)
                                      .withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(15),
                                ),
                                child: Icon(
                                  category['icon'],
                                  color: category['color'],
                                  size: 26,
                                ),
                              ),
                              const SizedBox(width: 20),
                              Text(
                                category['label'],
                                style: const TextStyle(
                                  fontSize: 17,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              const Spacer(),
                              const Icon(
                                Icons.arrow_forward_ios_rounded,
                                size: 14,
                                color: Colors.grey,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
                childCount: categories.length,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
